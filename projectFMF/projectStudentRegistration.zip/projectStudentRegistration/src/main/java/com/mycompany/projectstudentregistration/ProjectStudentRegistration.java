package com.mycompany.projectstudentregistration;
import entientes.studantData;
/**
 *
 * @author marcelo
 */
public class ProjectStudentRegistration {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
